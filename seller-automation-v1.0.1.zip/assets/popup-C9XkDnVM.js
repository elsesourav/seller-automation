import { j as jsxRuntimeExports, c as clientExports, R as React } from "./index--rbrrz96.js";
function PopupApp() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: "Popup Page" }) });
}
const container = document.getElementById("popup-root");
const root = clientExports.createRoot(container);
root.render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(PopupApp, {}) })
);
